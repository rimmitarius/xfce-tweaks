/*
 * Copyright (c) 2024 Brian Tarricone <brian@tarricone.org>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA
 */

#ifndef __XFW_SEAT_WAYLAND_H__
#define __XFW_SEAT_WAYLAND_H__

#include <glib-object.h>
#include <wayland-client-protocol.h>

#include "xfw-screen.h"
#include "xfw-seat-private.h"

G_BEGIN_DECLS

#define XFW_TYPE_SEAT_WAYLAND (xfw_seat_wayland_get_type())
G_DECLARE_FINAL_TYPE(XfwSeatWayland, xfw_seat_wayland, XFW, SEAT_WAYLAND, XfwSeat)

XfwSeatWayland *_xfw_seat_wayland_new(XfwScreen *screen, struct wl_seat *wl_seat, uint32_t global_name);
struct wl_seat *_xfw_seat_wayland_get_wl_seat(XfwSeatWayland *seat);
uint32_t _xfw_seat_wayland_get_global_name(XfwSeatWayland *seat);

G_END_DECLS

#endif /* __XFW_SEAT_WAYLAND_H__ */
